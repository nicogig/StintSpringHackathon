clearvars
close all
clc

DATA = xlsread('Desirability.xlsx');

desirability = DATA(:,1);

desirability1 = desirability(desirability>0.002);

mu = mean(desirability1);
sigma = std(desirability1);

figure(1)
histogram(desirability1, 'FaceColor', 'b')
hold on

grid on
grid minor
set(gca, 'FontSize', 18)

ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Desirability', 'FontSize', 25)
ylabel('Number of STINTs', 'FontSize', 25)
title('Desirability vs. STINTs', 'FontSize', 35)

txt1 = '\mu = 0.1598';
text(0.3,88,txt1,'FontSize',20)

txt2 = '\sigma = 0.0909';
text(0.3,85,txt2,'FontSize',20)

clear ax DATA txt1 txt2