clearvars
close all
clc

DATA = xlsread('duration_over_distance.xlsx');

duration_over_distance = DATA(:,1);

sigma = std(duration_over_distance(duration_over_distance<10));
mu = mean(duration_over_distance(duration_over_distance<10));

duration_over_distance_normalised_10 = (exp(10.*(duration_over_distance-mu)))./(exp(10.*(duration_over_distance-mu))+1);
duration_over_distance_normalised_5 = (exp(5.*(duration_over_distance-mu)))./(exp(5.*(duration_over_distance-mu))+1);
duration_over_distance_normalised_3_5 = (exp(3.5.*(duration_over_distance-mu)))./(exp(3.5.*(duration_over_distance-mu))+1);
duration_over_distance_normalised_2 = (exp(2.*(duration_over_distance-mu)))./(exp(2.*(duration_over_distance-mu))+1);

figure(1)
histogram(duration_over_distance_normalised_2, 'FaceColor', 'b')


figure(2)
histogram(duration_over_distance_normalised_3_5, 'FaceColor', 'b')


figure(3)
histogram(duration_over_distance_normalised_5, 'FaceColor', 'b')

figure(4)
histogram(duration_over_distance_normalised_10, 'FaceColor', 'b')

