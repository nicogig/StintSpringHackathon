clearvars
close all
clc

DATA = xlsread('Overall_Rating.xlsx');

ratings_all = DATA(:,1);

ratings = (ratings_all(~isnan(ratings_all)));
ratings1 = ratings(ratings>-1.5);

ratings_normalised3 = (exp(3.*ratings1))./(exp(3.*ratings1)+1);
ratings_normalised2 = (exp(2.*ratings1))./(exp(2.*ratings1)+1);
ratings_normalised1 = (exp(1.*ratings1))./(exp(1.*ratings1)+1);

sigma1 = std(ratings_normalised1);
mu1 = mean(ratings_normalised1);
sigma2 = std(ratings_normalised2);
mu2 = mean(ratings_normalised2);
sigma3 = std(ratings_normalised3);
mu3 = mean(ratings_normalised3);

figure(1)
histogram(ratings_normalised3,'BinWidth',0.025, 'FaceColor', 'b')

grid on
grid minor
set(gca, 'FontSize', 18)

ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Overall rating (normalised)', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Overall rating vs. number of students (normalised) (a = 3)', 'FontSize', 35)

figure(2)
histogram(ratings_normalised2,'BinWidth',0.025, 'FaceColor', 'r')

grid on
grid minor
set(gca, 'FontSize', 18)

ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Overall rating (normalised)', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Overall rating vs. number of students (normalised) (a = 2)', 'FontSize', 35)

figure(3)
histogram(ratings_normalised1,'BinWidth',0.025, 'FaceColor', 'g')

grid on
grid minor
set(gca, 'FontSize', 18)

ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Overall rating (normalised)', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Overall rating vs. number of students (normalised) (a = 1)', 'FontSize', 35)

