clearvars
close all
clc

DATA = xlsread('Duration&Distance.xlsx');

durationANDdistances = DATA(:,1);

figure(1)
histogram(durationANDdistances, 'FaceColor', 'b')
hold on

xlim([0 1])
grid on
grid minor
set(gca, 'FontSize', 18)
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Duration & Distance', 'FontSize', 25)
ylabel('Number of STINTs', 'FontSize', 25)
title('Duration & Distance vs. STINTs (Normalised)', 'FontSize', 35)

clear ax DATA