clearvars
close all
clc

DATA = xlsread('Distance.xlsx');

distances = DATA(:,1);

% Ignoring outliers (values of distance bigger than 15 km) in order to
% calculate sigma and mu.
sigma = std(distances(distances<15));
mu = mean(distances(distances<15));

figure(1)
histogram(distances,'BinWidth',1, 'FaceColor', 'b')
hold on

xlim([0 30])
grid on
grid minor
set(gca, 'FontSize', 18)
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Distance between student and business (km)', 'FontSize', 25)
ylabel('Number of STINTs', 'FontSize', 25)
title('Distance vs. STINTs', 'FontSize', 35)

txt1 = '\mu = 5.4287';
text(21,6.66E4,txt1,'FontSize',20)

txt2 = '\sigma = 2.5362';
text(21,6.3E4,txt2,'FontSize',20)

clear ax DATA txt1 txt2