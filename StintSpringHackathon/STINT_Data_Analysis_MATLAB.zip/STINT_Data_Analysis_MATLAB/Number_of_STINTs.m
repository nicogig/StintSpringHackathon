clearvars
close all
clc

DATA = xlsread('Number_of_STINTs.xlsx');

numberOfSTINTs = DATA(:,2);

edges = [0 4 7 10 50];

figure(1)
histogram(numberOfSTINTs,edges, 'FaceColor', 'b')
hold on
xlim([0 50])
grid on
grid minor
set(gca, 'FontSize', 18)
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Number of STINTs (any kind)', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Distribution of students vs. number of STINTs completed', 'FontSize', 35)

figure(2)
histogram(numberOfSTINTs, 'FaceColor', 'b')
hold on
xlim([0 50])
grid on
grid minor
set(gca, 'FontSize', 18)
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Number of STINTs (any kind)', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Distribution of students vs. number of STINTs completed', 'FontSize', 35)
