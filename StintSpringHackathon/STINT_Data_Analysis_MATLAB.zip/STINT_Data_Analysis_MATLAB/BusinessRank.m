clearvars
close all
clc

DATA = xlsread('BusinessRank.xlsx');

BusinessRank1 = DATA(:,1);

BusinessRank_Actual = BusinessRank1(~isnan(BusinessRank1));

mu = mean(BusinessRank_Actual);
sigma = std(BusinessRank_Actual);

figure(1)
histogram(BusinessRank_Actual, 'BinWidth',1, 'FaceColor', 'b')
hold on

grid on
grid minor
set(gca, 'FontSize', 18)
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Business rank', 'FontSize', 25)
ylabel('Number of businesses', 'FontSize', 25)
title('Spread of business ranks', 'FontSize', 35)

txt1 = '\mu = 2.5385';
text(0.3,90,txt1,'FontSize',20)

txt2 = '\sigma = 1.0323';
text(0.3,85,txt2,'FontSize',20)

clear ax DATA txt1 txt2 BusinessRank1