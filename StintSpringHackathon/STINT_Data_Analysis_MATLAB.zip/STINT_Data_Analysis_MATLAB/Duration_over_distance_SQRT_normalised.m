clearvars
close all
clc

DATA = xlsread('duration_over_distance_SQRT.xlsx');

duration_over_distance_SQRT = DATA(:,1);

sigma_sqrt = std(duration_over_distance_SQRT(duration_over_distance_SQRT<10));
mu_sqrt = mean(duration_over_distance_SQRT(duration_over_distance_SQRT<10));

duration_over_distance_SQRT_1 = (exp(1.*(duration_over_distance_SQRT-mu_sqrt)))./(exp(1.*(duration_over_distance_SQRT-mu_sqrt))+1);
duration_over_distance_SQRT_1_3 = (exp(1.3.*(duration_over_distance_SQRT-mu_sqrt)))./(exp(1.3.*(duration_over_distance_SQRT-mu_sqrt))+1);
duration_over_distance_SQRT_2 = (exp(2.*(duration_over_distance_SQRT-mu_sqrt)))./(exp(2.*(duration_over_distance_SQRT-mu_sqrt))+1);
duration_over_distance_SQRT_4 = (exp(4.*(duration_over_distance_SQRT-mu_sqrt)))./(exp(4.*(duration_over_distance_SQRT-mu_sqrt))+1);

figure(1)
histogram(duration_over_distance_SQRT_1, 'FaceColor', 'b')


figure(2)
histogram(duration_over_distance_SQRT_1_3, 'FaceColor', 'b')


figure(3)
histogram(duration_over_distance_SQRT_2, 'FaceColor', 'b')

figure(4)
histogram(duration_over_distance_SQRT_4, 'FaceColor', 'b')
