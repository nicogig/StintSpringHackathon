clearvars
close all
clc

DATA = xlsread('Overall_Rating.xlsx');

ratings_all = DATA(:,1);

ratings=(ratings_all(~isnan(ratings_all)));

% Ignoring outliers (values of ratings smaller than -1.5) in order to
% calculate sigma and mu to fit a gaussian curve to the histogram.
sigma = std(ratings(ratings>-1.5));
mu = mean(ratings(ratings>-1.5));

figure(1)
histogram(ratings, 'FaceColor', 'b')
hold on

grid on
grid minor
set(gca, 'FontSize', 18)

ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Overall rating', 'FontSize', 25)
ylabel('Number of students', 'FontSize', 25)
title('Overall rating vs. number of students', 'FontSize', 35)

txt1 = '\mu = 0.0265';
text(-2.95,275,txt1,'FontSize',20)

txt2 = '\sigma = 0.4043';
text(-2.95,260,txt2,'FontSize',20)