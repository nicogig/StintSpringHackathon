clearvars
close all
clc

DATA = xlsread('duration_over_distance.xlsx');
DATA2 = xlsread('duration_over_distance_SQRT.xlsx');

duration_over_distance = DATA(:,1);
duration_over_distance_SQRT = DATA2(:,1);

sigma = std(duration_over_distance(duration_over_distance<10));
mu = mean(duration_over_distance(duration_over_distance<10));

sigma_sqrt = std(duration_over_distance_SQRT(duration_over_distance_SQRT<10));
mu_sqrt = mean(duration_over_distance_SQRT(duration_over_distance_SQRT<10));

figure(1)
histogram(duration_over_distance, 'FaceColor', 'b')

grid on
grid minor
set(gca, 'FontSize', 18)
xlim([0 10])
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Duration over distance', 'FontSize', 25)
ylabel('Number of STINTs', 'FontSize', 25)
title('Duration over distance vs. STINTs', 'FontSize', 35)

txt1 = '\mu = 1.1461';
text(7,50000,txt1,'FontSize',20)

txt2 = '\sigma = 0.8845';
text(7,47500,txt2,'FontSize',20)


figure(2)
histogram(duration_over_distance_SQRT, 'FaceColor', 'r')

grid on
grid minor
set(gca, 'FontSize', 18)
xlim([0 10])
ax = gca;
ax.GridLineStyle = '-';
ax.GridColor = 'k';
ax.GridAlpha = 0.2;

xlabel('Duration over sqrt of distance', 'FontSize', 25)
ylabel('Number of STINTs', 'FontSize', 25)
title('Duration over sqrt of distance vs. STINTs', 'FontSize', 35)